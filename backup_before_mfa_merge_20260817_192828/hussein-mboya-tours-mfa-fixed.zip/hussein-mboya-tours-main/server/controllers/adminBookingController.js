import mongoose from "mongoose";

import {
  BOOKING_STATUSES,
  BOOKING_PAYMENT_STATUSES,
} from "../constants/bookingConstants.js";
import Booking from "../models/Booking.js";

/*
|--------------------------------------------------------------------------
| CONSTANTS
|--------------------------------------------------------------------------
*/




/*
|--------------------------------------------------------------------------
| GET ALL BOOKINGS
|--------------------------------------------------------------------------
*/

export const getAllBookings = async (req, res, next) => {
  try {
    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = Math.min(Number(req.query.limit) || 20, 100);
    const skip = (page - 1) * limit;

    const filter = {};

    if (
      req.query.status &&
      BOOKING_STATUSES.includes(req.query.status)
    ) {
      filter.status = req.query.status;
    }

    if (
      req.query.paymentStatus &&
      BOOKING_PAYMENT_STATUSES.includes(req.query.paymentStatus)
    ) {
      filter.paymentStatus = req.query.paymentStatus;
    }

    const [bookings, total] = await Promise.all([
      Booking.find(filter)
        .populate("customer", "name email phone")
        
        .populate("tour", "title name destination price")
        .populate("assignedGuide", "name email phone")
        .populate("assignedDriver", "name email phone")
        .populate("assignedVehicle")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),

      Booking.countDocuments(filter),
    ]);

    return res.status(200).json({
      success: true,
      page,
      limit,
      total,
      pages: Math.ceil(total / limit),
      count: bookings.length,
      bookings,
    });

  } catch (error) {
    next(error);
  }
};


/*
|--------------------------------------------------------------------------
| GET BOOKING BY ID
|--------------------------------------------------------------------------
*/

export const getBookingById = async (req, res, next) => {
  try {

    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid booking ID",
      });
    }


    const booking = await Booking.findById(req.params.id)
      .populate("customer", "name email phone")
      
      .populate("tour")
      .populate("assignedGuide", "name email phone")
      .populate("assignedDriver", "name email phone")
      .populate("assignedVehicle")
      .lean();


    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }


    return res.status(200).json({
      success: true,
      booking,
    });


  } catch (error) {
    next(error);
  }
};


/*
|--------------------------------------------------------------------------
| UPDATE BOOKING STATUS
|--------------------------------------------------------------------------
*/

export const updateBookingStatus = async (
  req,
  res,
  next
) => {

  try {

    const { status } = req.body;


    if (!BOOKING_STATUSES.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid booking status",
      });
    }


    const booking =
      await Booking.findByIdAndUpdate(
        req.params.id,
        {
          status: status,
        },
        {
          new: true,
          runValidators: true,
        }
      );


    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }


    return res.status(200).json({
      success: true,
      message: "Booking status updated successfully",
      booking,
    });


  } catch (error) {
    next(error);
  }

};


/*
|--------------------------------------------------------------------------
| ASSIGN BOOKING RESOURCES
|--------------------------------------------------------------------------
| Assign:
| - Tour Guide
| - Driver
| - Vehicle
|--------------------------------------------------------------------------
*/

export const assignResources = async (
  req,
  res,
  next
) => {

  try {

    const {
      guide,
      driver,
      vehicle,
    } = req.body;


    const booking =
      await Booking.findById(req.params.id);


    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }


    booking.assignedGuide =
      guideId || guide || null;

    booking.assignedDriver =
      driverId || driver || null;

    booking.assignedVehicle =
      vehicleId || vehicle || null;


    if (
      guideId ||
      guide ||
      driverId ||
      driver ||
      vehicleId ||
      vehicle
    ) {
      booking.status = "assigned";
    }


    await booking.save();


    await booking.populate([
      {
        path: "assignedGuide",
        select: "name email phone",
      },
      {
        path: "assignedDriver",
        select: "name email phone",
      },
      {
        path: "assignedVehicle",
      },
    ]);


    return res.status(200).json({
      success: true,
      message:
        "Resources assigned successfully",
      booking,
    });


  } catch (error) {
    next(error);
  }

};


/*
|--------------------------------------------------------------------------
| UPDATE PAYMENT STATUS
|--------------------------------------------------------------------------
*/

export const updatePaymentStatus = async (
  req,
  res,
  next
) => {

  try {

    const {
      status,
      mpesaReceipt,
    } = req.body;


    if (!BOOKING_PAYMENT_STATUSES.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid payment status",
      });
    }


    const booking =
      await Booking.findById(req.params.id);


    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      });
    }


    booking.paymentStatus = status;


    if (mpesaReceipt) {
      booking.mpesaReceipt =
        mpesaReceipt.trim();
    }


    await booking.save();


    return res.status(200).json({
      success: true,
      message:
        "Payment status updated successfully",
      booking,
    });


  } catch (error) {
    next(error);
  }

};

/*
|--------------------------------------------------------------------------
| DOWNLOAD BOOKING INVOICE
|--------------------------------------------------------------------------
*/

export const downloadBookingInvoice = async (
  req,
  res,
  next
) => {

  try {

    const booking = await Booking.findById(req.params.id)
      .populate("customer", "name email phone")
      .populate("tour", "title price")
      .lean();


    if (!booking) {
      return res.status(404).json({
        success:false,
        message:"Booking not found"
      });
    }


    return res.status(200).json({
      success:true,
      message:"Invoice data generated",
      invoice:{
        bookingNumber: booking.bookingNumber,
        customer: booking.customer,
        tour: booking.tour,
        amount: booking.totalAmount,
        status: booking.paymentStatus
      }
    });


  } catch(error) {
    next(error);
  }

};



/*
|--------------------------------------------------------------------------
| GET BOOKING TIMELINE
|--------------------------------------------------------------------------
*/

export const getBookingTimeline = async (
  req,
  res,
  next
) => {

  try {

    const booking = await Booking.findById(
      req.params.id
    )
    .select(
      "createdAt updatedAt status paymentStatus"
    )
    .lean();


    if (!booking) {
      return res.status(404).json({
        success:false,
        message:"Booking not found"
      });
    }


    const timeline = [
      {
        event:"Booking created",
        date:booking.createdAt,
        status:"created"
      },
      {
        event:"Booking status updated",
        date:booking.updatedAt,
        status:booking.status
      },
      {
        event:"Payment status",
        date:booking.updatedAt,
        status:booking.paymentStatus
      }
    ];


    return res.status(200).json({
      success:true,
      timeline
    });


  } catch(error) {
    next(error);
  }

};

