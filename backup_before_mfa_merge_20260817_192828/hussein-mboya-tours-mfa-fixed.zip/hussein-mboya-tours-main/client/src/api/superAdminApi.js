import axios from "./axios";

export const getSuperAdminDashboard = async () => {
  const response = await axios.get("/superadmin/dashboard");
  return response.data;
};

export const getAuditLogs = async () =>
  (await axios.get("/superadmin/audit")).data;

export const getSecurityStatus = async () =>
  (await axios.get("/superadmin/security")).data;

export const getDatabaseStatus = async () =>
  (await axios.get("/superadmin/database")).data;

export const getSystemHealth = async () =>
  (await axios.get("/superadmin/system")).data;

export const getApiMonitor = async () =>
  (await axios.get("/superadmin/api-monitor")).data;

export const getSettings = async () => {
  const response = await axios.get("/settings/public");
  return response.data;
};

export const updateSettings = async (data) => {
  const response = await axios.put("/admin/settings", data);
  return response.data;
};

export const getSecurityEvents = async () =>
  (await axios.get("/security/events")).data;

export const getRoles = async () => {
  const response = await axios.get("/admin/roles");
  return response.data.roles || [];
};

export const getRole = async (id) => {
  const response = await axios.get(`/admin/roles/${id}`);
  return response.data.role || response.data;
};

export const getPermissions = async () => {
  const response = await axios.get("/admin/roles/permissions/all");
  return response.data.permissions || [];
};

export const updateRolePermissions = async (id, permissions) => {
  const response = await axios.put(
    `/admin/roles/${id}/permissions`,
    { permissions },
  );

  return response.data;
};
